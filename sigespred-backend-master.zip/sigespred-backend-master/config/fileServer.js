const fileserverpath="D:/MTC/fileserverDDP/public/files/";
module.exports={fileserverpath}