const Entity = {
   Product: './Product'
};

module.exports = Entity;