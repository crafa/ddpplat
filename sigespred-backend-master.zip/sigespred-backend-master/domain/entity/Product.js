class Product {
   constructor() {

   }

   static getTypes() {
      return [{
         id: 1,
         nombre: 'STATISTICS_A'
      }];
   }
}

module.exports = Product;