//FALTAN USER Y PASS
module.exports = {
  transport: {
    host: 'smtp.zoho.eu',
    port: 465,
    secure: true,
  },
  host: 'smtp.zoho.eu',
  port: 465,
  secure: true,
};
