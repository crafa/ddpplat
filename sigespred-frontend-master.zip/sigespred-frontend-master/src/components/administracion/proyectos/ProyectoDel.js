import React from 'react';

const ProyectoDel = () => {
    return (
        <div>
            
        </div>
    );
};

export default ProyectoDel;