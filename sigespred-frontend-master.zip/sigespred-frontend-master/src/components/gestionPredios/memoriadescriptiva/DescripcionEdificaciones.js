import React from 'react';

const DescripcionEdificaciones = () => {
        return (
            <>

            </>
        );
    };

export default DescripcionEdificaciones;