import React from 'react';

const PropietarioRow = () => {
    return (
        <>
            <tr>
                <td>
                    <i className="fa fa-trash-o"></i>
                </td>
                <td>
                    122345678
                </td>
                <td>
                    John 
                </td>
                <td>
                   Mnezoda
                </td>
                <td>
                   Calle las Palmeras 3005 - Lince
                </td>
                <td>
                    SI
                </td>
            </tr>
        </>
    );
};

export default PropietarioRow;