import React, {Component} from 'react';

class CuadroHeader extends Component {
    render() {
        return (
           
                <thead>
                <tr>   <th><h4>PREDIOS</h4></th>
                    <th title={'Proceso 01:'}>P-1</th>
                    <th>P-2</th>
                    <th>P-3</th>
                    <th>P-4</th>
                    <th>P-5</th>
                    <th>P-6</th>
                    <th>P-7</th>
                    <th>P-8</th>
                    <th>P-9</th>
                    <th>P-10</th>
                    <th>P-11</th>
                    <th>P-12</th>
                    <th>P-13</th>
                    <th>P-14</th>
                    <th>P-15</th>

                </tr>
                </thead>
          
        );
    }
}

export default CuadroHeader;