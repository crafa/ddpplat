import React, {Component} from 'react';
import InputGestion from "./inputGestion";
import InputDiptra from "./InputDiptra";

class InputsVial extends Component {
    render() {
        return (div
            <InputGestion/>
            <InputDiptra/>
        );
    }
}

export default InputsVial;