import React from 'react';
import { Route } from 'react-router-dom';

const RouteMod12Reportes = () => {
    return (
        <>
            
        </>
    );
};

export default RouteMod12Reportes;