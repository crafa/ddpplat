import React from 'react';
import { Route } from 'react-router-dom';


const RouteMod10Dashboard = () => {
    return (
        <div>
            
        </div>
    );
};

export default RouteMod10Dashboard;