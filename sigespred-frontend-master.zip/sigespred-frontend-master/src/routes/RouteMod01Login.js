import Login from "../sigespred/m001_login/Login";

const RouteMod01Login = [
    {path: "/", component: Login},
    {path: "/login", component: Login}
]

export default RouteMod01Login;

