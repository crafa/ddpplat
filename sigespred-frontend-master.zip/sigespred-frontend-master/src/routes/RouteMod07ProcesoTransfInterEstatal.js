import React from 'react';
import { Route } from 'react-router-dom';




const RouteMod07ProcesoTransfInterEstatal = () => {
    return (
        <>
     

        </>
    );
};

export default RouteMod07ProcesoTransfInterEstatal;
