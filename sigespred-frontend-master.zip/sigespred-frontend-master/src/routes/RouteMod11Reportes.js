import React from 'react';
import { Route } from 'react-router-dom';

import React from 'react';

const RouteMod11Reportes = () => {
    return (
        <div>
            
        </div>
    );
};

export default RouteMod11Reportes;