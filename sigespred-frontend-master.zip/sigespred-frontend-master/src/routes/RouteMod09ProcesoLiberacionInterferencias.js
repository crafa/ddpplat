import React from 'react';
import { Route } from 'react-router-dom';



const RouteMod09ProcesoLiberacionInterferencias = () => {
    return (
        <>
            
        </>
    );
};

export default RouteMod09ProcesoLiberacionInterferencias;