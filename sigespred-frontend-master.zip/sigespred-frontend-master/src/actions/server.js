export const URL_SERVER='http://localhost:8000/api';
export const ELIMINAR_BRIGADISTA = 'ELIMINAR_BRIGADISTA';